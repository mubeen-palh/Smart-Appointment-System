import React from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { FaTachometerAlt, FaCalendarAlt, FaChartBar, FaUserMd, FaFileAlt, FaQuestionCircle } from "react-icons/fa";

import DoctorProfile from "./components/DoctorProfile";
import DoctorBookings from "./components/DoctorBookings";
import DoctorAppointments from "./components/DoctorAppointments";
import Help from "./components/Help";
import DoctorReports from "./components/DoctorReports";

function App() {
  return (
    <Router>
      <div className="dashboard-container">
        <aside className="sidebar">
          <div className="logo">Doctor</div>
          <nav className="nav">
            <Link to="/" className="nav-item">
              <FaTachometerAlt className="nav-icon" /> Profile
            </Link>
            <Link to="/bookings" className="nav-item">
              <FaCalendarAlt className="nav-icon" /> View Bookings
            </Link>
            <Link to="/reports" className="nav-item">
              <FaChartBar className="nav-icon" /> View Reports
            </Link>
            <Link to="/appointments" className="nav-item">
              <FaQuestionCircle className="nav-icon" /> Appointments
            </Link>
            <Link to="/help" className="nav-item">
              <FaQuestionCircle className="nav-icon" /> Help
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="main-content">
          <Routes>
            <Route path="/" element={<DoctorProfile />} />
            <Route path="/appointments" element={<DoctorAppointments />} />
            <Route path="/bookings" element={<DoctorBookings />} />
            <Route path="/reports" element={<DoctorReports />} />
            <Route path="/help" element={<Help />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
