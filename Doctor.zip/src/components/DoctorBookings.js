import React from "react";


// Fetch this data using web API
const DoctorBookings = () => {
  const bookings = [
    { id: 1, patientName: "Jane Smith", date: "25 Jan, 2024", history: "Diabetes Type II" },
    { id: 2, patientName: "Mark Lee", date: "28 Jan, 2024", history: "High Blood Pressure" },
  ];

  return (
    <div>
      <h2>View Bookings</h2>
      <table>
        <thead>
          <tr>
            <th>Patient Name</th>
            <th>Date</th>
            <th>History</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((booking) => (
            <tr key={booking.id}>
              <td>{booking.patientName}</td>
              <td>{booking.date}</td>
              <td>{booking.history}</td>
              <td>
                <button>Approve</button>
                <button>Disapprove</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DoctorBookings;
