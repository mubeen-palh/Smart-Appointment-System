import React, { useState } from "react";

const DoctorProfile = () => {
  const [isEditing, setIsEditing] = useState(false);

  // fetch this data using API
  const [profile, setProfile] = useState({
    name: "Dr. John Doe",
    specialty: "Cardiologist",
    experience: "10 years",
    address: "123 Main St, Springfield",
    phone: "+1 234-567-890",
    email: "john.doe@example.com",
  });

  const handleEdit = () => setIsEditing(!isEditing);
  const handleChange = (e) => setProfile({ ...profile, [e.target.name]: e.target.value });
  const handleSave = () => setIsEditing(false);

  return (
    <div className="profile">
      <h2>Profile</h2>
      {isEditing ? (
        <div>
          <input name="name" value={profile.name} onChange={handleChange} />
          <input name="specialty" value={profile.specialty} onChange={handleChange} />
          <input name="experience" value={profile.experience} onChange={handleChange} />
          <input name="address" value={profile.address} onChange={handleChange} />
          <input name="phone" value={profile.phone} onChange={handleChange} />
          <input name="email" value={profile.email} onChange={handleChange} />
          <button onClick={handleSave}>Save</button>
        </div>
      ) : (
        <div>
          <p><strong>Name:</strong> {profile.name}</p>
          <p><strong>Specialty:</strong> {profile.specialty}</p>
          <p><strong>Experience:</strong> {profile.experience}</p>
          <p><strong>Address:</strong> {profile.address}</p>
          <p><strong>Phone:</strong> {profile.phone}</p>
          <p><strong>Email:</strong> {profile.email}</p>
          <button onClick={handleEdit}>Edit Profile</button>
        </div>
      )}
    </div>
  );
};

export default DoctorProfile;
