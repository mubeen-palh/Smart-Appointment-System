import React from "react";

const Help = () => {
  return (
    <div>
      <h2>Help</h2>
      <p>For any issues, please contact support@example.com or call +1 800-123-456.</p>
    </div>
  );
};

export default Help;
