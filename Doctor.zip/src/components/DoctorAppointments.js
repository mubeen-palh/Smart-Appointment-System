import React from "react";

// Fetch this data from API
const DoctorAppointments = () => {
  const appointments = [
    { id: 1, patientName: "Jane Smith", time: "10:00 AM", date: "26 Jan, 2024" },
    { id: 2, patientName: "Mark Lee", time: "2:00 PM", date: "27 Jan, 2024" },
  ];

  return (
    <div>
      <h2>Appointments</h2>
      <ul>
        {appointments.map((appointment) => (
          <li key={appointment.id}>
            {appointment.patientName} - {appointment.time} on {appointment.date}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DoctorAppointments;
