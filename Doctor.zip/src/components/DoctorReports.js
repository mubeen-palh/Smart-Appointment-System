import React from "react";

const DoctorReports = () => {

  // fetch this data using API
  const reports = [
    { testName: "Blood Test", referredBy: "Dr. Smith", date: "20 Jan, 2024", comments: "Normal", result: "Positive" },
    { testName: "X-Ray", referredBy: "Dr. Brown", date: "22 Jan, 2024", comments: "Check fracture", result: "Normal" },
  ];

  return (
    <div>
      <h2>Reports</h2>
      <table>
        <thead>
          <tr>
            <th>Test Name</th>
            <th>Referred By</th>
            <th>Date</th>
            <th>Comments</th>
            <th>Result</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((report, index) => (
            <tr key={index}>
              <td>{report.testName}</td>
              <td>{report.referredBy}</td>
              <td>{report.date}</td>
              <td>{report.comments}</td>
              <td>{report.result}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DoctorReports;
