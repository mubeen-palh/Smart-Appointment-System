import React from "react";

function Appointments() {
  return (
    <div>
        {/* // fetch this data using API */}
      <h1>Your Appointments</h1>
      <p>List of all your appointments</p>
      <table>
              <thead>
                <tr>
                  <th>Appointment ID</th>
                  <th>Doctor Name</th>
                  <th>Date</th>
                  <th>Comments</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>SD12345678</td>
                  <td>Dr. Rafiqul Islam</td>
                  <td>28 Jan, 2024</td>
                  <td>Good! Take rest</td>
                  <td>OK</td>
                </tr>
                <tr>
                  <td>SD12345699</td>
                  <td>Dr. Fahim Ahmed</td>
                  <td>12 Jan, 2024</td>
                  <td>Waiting for diagram</td>
                  <td>Ok</td>
                </tr>
              </tbody>
            </table>
    </div>
  );
}

export default Appointments;
