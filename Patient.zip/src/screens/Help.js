import React from "react";

function Help() {
  return (
    <div>
      <h1>Help</h1>
      <p>Here you can find help and FAQs...</p>
    </div>
  );
}

export default Help;
