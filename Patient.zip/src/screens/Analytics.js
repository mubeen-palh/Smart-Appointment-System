import React from "react";

function Analytics() {
  return (
    <div>
      <h1>Analytics</h1>
      <p>Analytics data and charts will be displayed here.</p>
    </div>
  );
}

export default Analytics;
