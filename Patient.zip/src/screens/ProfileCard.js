import React from "react";
import "./ProfileCard.css";
import { FaPhone } from "react-icons/fa";

function ProfileCard() {
  return (
    <div className="profile-card">
      {/* Profile Picture */}
      <div className="profile-picture">
        <img
          src="https://plus.unsplash.com/premium_photo-1689530775582-83b8abdb5020?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cmFuZG9tJTIwcGVyc29ufGVufDB8fDB8fHww" // Replace with actual image URL
          alt="Profile"
        />
      </div>

      {/* Profile Details */}
      {/*   // fetch this Patient Data using API */}
      <div className="profile-details">
        <div className="profile-header">
          <h2>Marth Smith</h2>
          <p>65yrs old • Male</p>
          <button className="call-button">
            <FaPhone />
          </button>
        </div>
        <div className="profile-info">
          <p>7246, Woodland Rd, Waukesha, WI 53186</p>
          <p>Cell: +1 310-351-7774</p>
          <p>Last Appointment: 24 Jan, 2024</p>
        </div>
      </div>
    </div>
  );
}

export default ProfileCard;
