import React from "react";

function Doctors() {
  return (
    <div>
        {/* // fetch DOCTOR DETAILS using API */}
      <h1>Doctors</h1>
      <p>Details about the doctors will appear here.</p>
    </div>
  );
}

export default Doctors;
