import React from "react";
import ProfileCard from "./ProfileCard"; 

function Dashboard() {
  return (
    <div>
      {/* Main Content */}
      <main className="main-content">
        {/* Header */}
        <header className="header">
          <input
            type="text"
            placeholder="Search patients, invoice, appointments, etc."
            className="search-bar"
          />
        </header>

        {/* Dashboard Content */}
        <div className="dashboard">
          <section className="dashboard-section performance">
            <h3>Overall Performance</h3>
            <div className="score-container">
              <div className="score-circle">468</div>
              <p>Marth Smith is healthier than 95% of people</p>
            </div>
            <button className="btn">Check Full Report</button>
          </section>

          {/* Analytics */}
          <section className="dashboard-section analytics">

            {/* Profile Section */}
            <div className="profile-section">
              <h4>Profile</h4>
              <ProfileCard /> 
            </div>
          </section>

          {/* Lab Reports */}
          <section className="dashboard-section lab-reports">
            <h3>Lab Reports</h3>
            <table>
              <thead>
                <tr>
                  <th>Test Name</th>
                  <th>Referred By</th>
                  <th>Date</th>
                  <th>Comments</th>
                  <th>Result</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Electrocardiography</td>
                  <td>Dr. Rafiqul Islam</td>
                  <td>28 Jan, 2024</td>
                  <td>Good! Take rest</td>
                  <td>Normal</td>
                </tr>
                <tr>
                  <td>Liver Biopsy</td>
                  <td>Dr. Fahim Ahmed</td>
                  <td>12 Jan, 2024</td>
                  <td>Waiting for diagram</td>
                  <td>Hepatitis</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* Appointments */}
          <section className="dashboard-section appointments">
            <h3>Appointments</h3>
            <div className="appointment-card">
              <p>Dr. Friedrich Ziccardi</p>
              <p>Cardiologist - 17:00</p>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;
