import React from "react";

function Reports() {
  return (
    <div>
      <h1>Reports</h1>
      <p>All your reports will be shown here.</p>
      {/* Show Reports Table here  */}
    </div>
  );
}

export default Reports;
