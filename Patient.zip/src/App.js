import React from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { FaTachometerAlt, FaCalendarAlt, FaChartBar, FaUserMd, FaFileAlt, FaQuestionCircle } from "react-icons/fa";
import Dashboard from "./screens/Dashboard";
import Appointments from "./screens/Appointments";
import Analytics from "./screens/Analytics";
import Doctors from "./screens/Doctors";
import Reports from "./screens/Reports";
import Help from "./screens/Help";

function App() {
  return (
    <Router>
      <div className="dashboard-container">
        {/* Sidebar */}
        <aside className="sidebar">
          <div className="logo">Patient</div>
          <nav className="nav">
            <Link to="/" className="nav-item">
              <FaTachometerAlt className="nav-icon" /> Dashboard
            </Link>
            <Link to="/appointments" className="nav-item">
              <FaCalendarAlt className="nav-icon" /> Appointments
            </Link>
            <Link to="/analytics" className="nav-item">
              <FaChartBar className="nav-icon" /> Analytics
            </Link>
            <Link to="/doctors" className="nav-item">
              <FaUserMd className="nav-icon" /> Doctor
            </Link>
            <Link to="/reports" className="nav-item">
              <FaFileAlt className="nav-icon" /> Reports
            </Link>
            <Link to="/help" className="nav-item">
              <FaQuestionCircle className="nav-icon" /> Help
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/doctors" element={<Doctors />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/help" element={<Help />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
